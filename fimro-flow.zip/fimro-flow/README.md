# Fimro Flow v2 — All-in-One File Toolkit

A modern, privacy-first web app with **55+ tools** for PDF, image, document, code, and everyday utility tasks. Everything runs locally in your browser — files never leave your device.

## What's new in v2

- **Brand-new design** — modern gradients, glassmorphism, polished animations.
- **Dark mode** with system-preference auto-switch.
- **Live search** with fuzzy matching (`/` to focus).
- **Favorites** — star tools to pin them at the top.
- **Recently used** — your last 6 tools are one click away.
- **Toast notifications** for non-blocking feedback.
- **Keyboard shortcuts** — `/`, `Esc`, `Shift+T`, `Ctrl+Enter`, `?`.
- **Settings drawer** — theme, toasts, confirm-on-reset, background animation.
- **Drag-and-drop** + click-to-browse everywhere.
- **Working tool engine** — many tools rewritten with real implementations (pdf-lib, canvas, JSZip, QRCode.js, JsBarcode, CryptoJS).
- **Mobile-responsive** with collapsing nav.
- **Accessible** — proper ARIA, keyboard navigation, focus rings.

## Tool catalog

### PDF (12)
Merge · Split · Compress · Rotate · Organize · PDF → Images · PDF → Text · PDF → CSV · Protect · Unlock · Images → PDF · Text → PDF

### Image (12)
Compress · Resize · Crop · Rotate · Flip · Convert · Filters · Photo Editor · Watermark · Remove Background · Meme Generator · Image Inspector

### Documents (8)
Word Counter · Text Case Converter · Remove Duplicates · Sort Lines · Find & Replace · Reverse Text · CSV ↔ JSON · Slugify

### Converters (10)
Base64 Encode/Decode · URL Encode/Decode · HTML Encode/Decode · HTML → Text · Markdown → HTML · JSON Formatter · XML Formatter · CSS Minifier · JS Minifier

### Utilities (13)
QR Code Generator · Barcode Generator · Password Generator · Hash Generator (MD5/SHA1/SHA256/SHA512) · UUID Generator · Lorem Ipsum · Color Converter (HEX/RGB/HSL/CMYK) · Timestamp Converter · Unit Converter · ZIP Files · Unzip Archive · Signature Generator · Reading Time Estimator

## Getting started

Just open `index.html` in any modern browser. No build step, no server.

```
fimro-flow/
├── index.html      # App shell
├── styles.css      # Modern design system + dark mode
├── script.js       # All tools + UI logic
├── logo.svg
└── README.md
```

## Keyboard shortcuts

| Key             | Action                  |
|-----------------|-------------------------|
| `/`             | Focus search            |
| `Esc`           | Close modal / drawer    |
| `Shift + T`     | Toggle dark mode        |
| `?`             | Show shortcuts help     |
| `Ctrl/Cmd + Enter` | Run current tool     |

## Privacy

- **100% client-side** — your files never leave your browser.
- **No tracking**, no accounts, no analytics, no ads.
- Your favorites and recent tools are stored in `localStorage` only.

## Browser support

Modern Chromium, Firefox, Safari, Edge. Some advanced features (image clipboard, `color-mix()`) need recent browsers.

## Tech

- HTML + CSS (custom design system, no framework)
- Vanilla JavaScript (~95 KB), no build step
- [pdf-lib](https://pdf-lib.js.org), [jsPDF](https://github.com/parallax/jsPDF), [JSZip](https://stuk.github.io/jszip/), [QRCode.js](https://davidshimjs.github.io/qrcodejs/), [JsBarcode](https://github.com/lindell/JsBarcode), [CryptoJS](https://cryptojs.gitbook.io/docs/)
- Font Awesome 6 icons, Inter font

## License

Free to use and modify for personal and commercial projects.
