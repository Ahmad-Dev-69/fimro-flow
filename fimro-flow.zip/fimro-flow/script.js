/* =========================================================
   FIMRO FLOW v2.0 — App engine
   ========================================================= */
(function () {
'use strict';

/* ---------------- State ---------------- */
const STORAGE = {
    favs:    'ff:favorites',
    recent:  'ff:recent',
    theme:   'ff:theme',
    toasts:  'ff:toasts',
    confirm: 'ff:confirm',
    aura:    'ff:aura',
    usage:   'ff:usage',
};

const state = {
    favorites: new Set(loadJSON(STORAGE.favs, [])),
    recent:    loadJSON(STORAGE.recent, []),
    theme:     localStorage.getItem(STORAGE.theme) || 'system',
    toasts:    loadJSON(STORAGE.toasts, true),
    confirm:   loadJSON(STORAGE.confirm, false),
    aura:      loadJSON(STORAGE.aura, true),
    usage:     loadJSON(STORAGE.usage, { date: today(), count: 0 }),
    currentTool: null,
    files: [],
};

function loadJSON(k, fallback) {
    try { const v = localStorage.getItem(k); return v === null ? fallback : JSON.parse(v); }
    catch { return fallback; }
}
function saveJSON(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
function today() { return new Date().toISOString().slice(0,10); }

/* ---------------- Tool catalog ---------------- */
/* Each tool: { id, name, desc, cat, icon, modes: ['file'|'text'|'both'], accept, multiple, options, run } */

const TOOLS = [
    /* ===== PDF (12) ===== */
    { id:'pdf-merge', name:'Merge PDF', desc:'Combine multiple PDFs into one document', cat:'pdf', icon:'fa-layer-group',
      modes:['file'], accept:'application/pdf', multiple:true, run:runMergePDF },
    { id:'pdf-split', name:'Split PDF', desc:'Split a PDF into one file per page', cat:'pdf', icon:'fa-scissors',
      modes:['file'], accept:'application/pdf', options:[
        { id:'splitMode', label:'Split mode', type:'select', options:['Each page','Every 2 pages','Every 3 pages'] }
      ], run:runSplitPDF },
    { id:'pdf-compress', name:'Compress PDF', desc:'Reduce PDF size (saves metadata streamlined copy)', cat:'pdf', icon:'fa-file-zipper',
      modes:['file'], accept:'application/pdf', run:runCompressPDF },
    { id:'pdf-rotate', name:'Rotate PDF', desc:'Rotate every page of a PDF', cat:'pdf', icon:'fa-rotate',
      modes:['file'], accept:'application/pdf', options:[
        { id:'rot', label:'Rotation', type:'select', options:['90° Clockwise','180°','90° Counter-clockwise'] }
      ], run:runRotatePDF },
    { id:'pdf-organize', name:'Organize PDF', desc:'Reorder or remove PDF pages', cat:'pdf', icon:'fa-sort',
      modes:['file'], accept:'application/pdf', options:[
        { id:'order', label:'Page order (e.g. 3,1,2 or blank = reverse)', type:'text', placeholder:'1,3,2 or leave blank' }
      ], run:runOrganizePDF },
    { id:'pdf-to-images', name:'PDF → Images', desc:'Convert PDF pages to image files', cat:'pdf', icon:'fa-images',
      modes:['file'], accept:'application/pdf', options:[
        { id:'imgFmt', label:'Format', type:'select', options:['PNG','JPG'] }
      ], run:runPDFToImages },
    { id:'pdf-to-text', name:'PDF → Text', desc:'Extract readable text from a PDF', cat:'pdf', icon:'fa-file-lines',
      modes:['file'], accept:'application/pdf', run:runPDFToText },
    { id:'pdf-to-excel', name:'PDF → CSV', desc:'Pull text rows from a PDF into CSV', cat:'pdf', icon:'fa-file-csv',
      modes:['file'], accept:'application/pdf', run:runPDFToCSV },
    { id:'pdf-protect', name:'Protect PDF', desc:'Add an owner password/metadata flag', cat:'pdf', icon:'fa-lock',
      modes:['file'], accept:'application/pdf', options:[
        { id:'pwd', label:'New password', type:'password', placeholder:'Enter password' }
      ], run:runProtectPDF },
    { id:'pdf-unlock', name:'Unlock PDF', desc:'Open with password and re-save without restrictions', cat:'pdf', icon:'fa-unlock',
      modes:['file'], accept:'application/pdf', options:[
        { id:'pwd', label:'Password (if known)', type:'password', placeholder:'Enter password' }
      ], run:runUnlockPDF },
    { id:'image-to-pdf', name:'Images → PDF', desc:'Bundle images into a single PDF', cat:'pdf', icon:'fa-file-pdf',
      modes:['file'], accept:'image/*', multiple:true, options:[
        { id:'pageSize', label:'Page', type:'select', options:['Fit image','A4','Letter'] }
      ], run:runImagesToPDF },
    { id:'text-to-pdf', name:'Text → PDF', desc:'Convert text to a clean PDF', cat:'pdf', icon:'fa-file-pen',
      modes:['text'], options:[
        { id:'fontSize', label:'Font size', type:'number', value:12, min:8, max:48 }
      ], run:runTextToPDF },

    /* ===== Image (13) ===== */
    { id:'image-compress', name:'Compress Image', desc:'Lossy compression with adjustable quality', cat:'image', icon:'fa-compress',
      modes:['file'], accept:'image/*', options:[
        { id:'q', label:'Quality', type:'range', min:10, max:100, value:80, suffix:'%' }
      ], run:runImageCompress },
    { id:'image-resize', name:'Resize Image', desc:'Change image dimensions', cat:'image', icon:'fa-expand',
      modes:['file'], accept:'image/*', options:[
        { id:'w', label:'Width (px)', type:'number', value:800, min:1, max:10000 },
        { id:'h', label:'Height (px)', type:'number', value:600, min:1, max:10000 },
        { id:'keep', label:'Maintain aspect ratio', type:'checkbox', checked:true }
      ], run:runImageResize },
    { id:'image-crop', name:'Crop Image', desc:'Crop to a region by coordinates', cat:'image', icon:'fa-crop-simple',
      modes:['file'], accept:'image/*', options:[
        { id:'x', label:'X', type:'number', value:0, min:0 },
        { id:'y', label:'Y', type:'number', value:0, min:0 },
        { id:'cw', label:'Width', type:'number', value:400, min:1 },
        { id:'ch', label:'Height', type:'number', value:400, min:1 }
      ], run:runImageCrop },
    { id:'image-rotate', name:'Rotate Image', desc:'Rotate by a fixed or custom angle', cat:'image', icon:'fa-arrows-rotate',
      modes:['file'], accept:'image/*', options:[
        { id:'angle', label:'Angle', type:'select', options:['90° Clockwise','180°','90° Counter-clockwise','Custom'] },
        { id:'custom', label:'Custom angle (deg)', type:'number', value:45 }
      ], run:runImageRotate },
    { id:'image-flip', name:'Flip / Mirror', desc:'Mirror image horizontally, vertically, or both', cat:'image', icon:'fa-arrows-left-right',
      modes:['file'], accept:'image/*', options:[
        { id:'dir', label:'Direction', type:'select', options:['Horizontal','Vertical','Both'] }
      ], run:runImageFlip },
    { id:'image-convert', name:'Convert Image', desc:'Change image format', cat:'image', icon:'fa-arrow-right-arrow-left',
      modes:['file'], accept:'image/*', options:[
        { id:'fmt', label:'Convert to', type:'select', options:['JPG','PNG','WEBP','BMP'] }
      ], run:runImageConvert },
    { id:'image-filters', name:'Image Filters', desc:'Apply popular CSS filters', cat:'image', icon:'fa-wand-magic-sparkles',
      modes:['file'], accept:'image/*', options:[
        { id:'flt', label:'Filter', type:'select', options:['Grayscale','Sepia','Blur','Invert','Brightness +','Contrast +','Saturate +'] }
      ], run:runImageFilter },
    { id:'photo-editor', name:'Photo Editor', desc:'Adjust brightness, contrast, saturation', cat:'image', icon:'fa-palette',
      modes:['file'], accept:'image/*', options:[
        { id:'b', label:'Brightness', type:'range', min:0, max:200, value:100, suffix:'%' },
        { id:'c', label:'Contrast', type:'range', min:0, max:200, value:100, suffix:'%' },
        { id:'s', label:'Saturation', type:'range', min:0, max:200, value:100, suffix:'%' }
      ], run:runPhotoEditor },
    { id:'image-watermark', name:'Add Watermark', desc:'Stamp text onto your image', cat:'image', icon:'fa-stamp',
      modes:['file'], accept:'image/*', options:[
        { id:'text', label:'Watermark text', type:'text', placeholder:'© Your name', value:'© Watermark' },
        { id:'op', label:'Opacity', type:'range', min:10, max:100, value:50, suffix:'%' },
        { id:'pos', label:'Position', type:'select', options:['Center','Bottom-right','Bottom-left','Top-right','Top-left','Diagonal'] }
      ], run:runWatermark },
    { id:'remove-bg', name:'Remove Background', desc:'Remove a solid background by color tolerance', cat:'image', icon:'fa-eraser',
      modes:['file'], accept:'image/*', options:[
        { id:'tol', label:'Tolerance', type:'range', min:0, max:100, value:25, suffix:'%' },
        { id:'targetColor', label:'Target color (blank = top-left pixel)', type:'text', placeholder:'#ffffff' }
      ], run:runRemoveBg },
    { id:'meme-gen', name:'Meme Generator', desc:'Add top and bottom text to an image', cat:'image', icon:'fa-face-grin-squint-tears',
      modes:['file'], accept:'image/*', options:[
        { id:'top', label:'Top text', type:'text', placeholder:'One does not simply…' },
        { id:'bot', label:'Bottom text', type:'text', placeholder:'…write a fast app' }
      ], run:runMeme },
    { id:'image-info', name:'Image Inspector', desc:'Inspect dimensions, size, mime, dominant color', cat:'image', icon:'fa-circle-info',
      modes:['file'], accept:'image/*', run:runImageInfo },

    /* ===== Document (8) ===== */
    { id:'word-counter', name:'Word Counter', desc:'Count words, characters, lines, reading time', cat:'doc', icon:'fa-calculator',
      modes:['text'], run:runWordCounter },
    { id:'text-case', name:'Text Case Converter', desc:'UPPER, lower, Title, Sentence, iNVERT', cat:'doc', icon:'fa-font',
      modes:['text'], options:[
        { id:'caseType', label:'Case', type:'select', options:['UPPERCASE','lowercase','Title Case','Sentence case','iNVERT cASE','camelCase','snake_case','kebab-case'] }
      ], run:runTextCase },
    { id:'remove-duplicates', name:'Remove Duplicate Lines', desc:'Deduplicate text line by line', cat:'doc', icon:'fa-clone',
      modes:['text'], options:[
        { id:'sortAfter', label:'Sort after dedupe', type:'checkbox', checked:false },
        { id:'trim', label:'Trim whitespace before comparing', type:'checkbox', checked:true }
      ], run:runRemoveDuplicates },
    { id:'sort-lines', name:'Sort Lines', desc:'Alphabetical or reverse sort', cat:'doc', icon:'fa-arrow-up-1-9',
      modes:['text'], options:[
        { id:'mode', label:'Mode', type:'select', options:['A → Z','Z → A','Length (short → long)','Length (long → short)','Random shuffle'] }
      ], run:runSortLines },
    { id:'find-replace', name:'Find & Replace', desc:'Replace text quickly (supports regex)', cat:'doc', icon:'fa-magnifying-glass',
      modes:['text'], options:[
        { id:'find', label:'Find', type:'text', placeholder:'text to find' },
        { id:'rep',  label:'Replace with', type:'text', placeholder:'replacement' },
        { id:'regex', label:'Use as regex', type:'checkbox', checked:false },
        { id:'ci', label:'Case-insensitive', type:'checkbox', checked:false }
      ], run:runFindReplace },
    { id:'text-reverse', name:'Reverse Text', desc:'Reverse characters, words, or lines', cat:'doc', icon:'fa-right-left',
      modes:['text'], options:[
        { id:'rmode', label:'Reverse by', type:'select', options:['Characters','Words','Lines'] }
      ], run:runReverseText },
    { id:'csv-to-json', name:'CSV ↔ JSON', desc:'Convert between CSV and JSON', cat:'doc', icon:'fa-table',
      modes:['text'], options:[
        { id:'dir', label:'Direction', type:'select', options:['CSV → JSON','JSON → CSV'] }
      ], run:runCSVJSON },
    { id:'slugify', name:'Slugify', desc:'Make URL-friendly slugs', cat:'doc', icon:'fa-link',
      modes:['text'], run:runSlugify },

    /* ===== Converters (10) ===== */
    { id:'base64-encode', name:'Base64 Encode', desc:'Encode text or file to Base64', cat:'convert', icon:'fa-shield-halved',
      modes:['both'], accept:'*', run:runBase64Encode },
    { id:'base64-decode', name:'Base64 Decode', desc:'Decode Base64 to text', cat:'convert', icon:'fa-shield',
      modes:['text'], run:runBase64Decode },
    { id:'url-encode', name:'URL Encode / Decode', desc:'percent-encoding for URLs', cat:'convert', icon:'fa-link',
      modes:['text'], options:[
        { id:'action', label:'Action', type:'select', options:['Encode','Decode'] }
      ], run:runUrlEncode },
    { id:'html-encode', name:'HTML Encode / Decode', desc:'Encode/decode HTML entities', cat:'convert', icon:'fa-code',
      modes:['text'], options:[
        { id:'action', label:'Action', type:'select', options:['Encode','Decode'] }
      ], run:runHtmlEncode },
    { id:'html-to-text', name:'HTML → Text', desc:'Strip tags from HTML', cat:'convert', icon:'fa-file-code',
      modes:['text'], run:runHtmlToText },
    { id:'md-to-html', name:'Markdown → HTML', desc:'Lightweight Markdown to HTML conversion', cat:'convert', icon:'fa-markdown',
      modes:['text'], run:runMarkdown },
    { id:'json-formatter', name:'JSON Formatter', desc:'Validate and beautify JSON', cat:'convert', icon:'fa-brackets-curly',
      modes:['text'], options:[
        { id:'indent', label:'Indent', type:'number', value:2, min:0, max:8 },
        { id:'sort', label:'Sort keys', type:'checkbox', checked:false }
      ], run:runJsonFormat },
    { id:'xml-formatter', name:'XML Formatter', desc:'Pretty print XML', cat:'convert', icon:'fa-code',
      modes:['text'], run:runXmlFormat },
    { id:'css-minify', name:'CSS Minifier', desc:'Compress CSS', cat:'convert', icon:'fa-css3-alt',
      modes:['text'], run:runMinifyCSS },
    { id:'js-minify', name:'JavaScript Minifier', desc:'Compress JavaScript (lightweight)', cat:'convert', icon:'fa-js',
      modes:['text'], run:runMinifyJS },

    /* ===== Utilities (13) ===== */
    { id:'qr-gen', name:'QR Code Generator', desc:'Make a high-quality QR code', cat:'util', icon:'fa-qrcode',
      modes:['text'], options:[
        { id:'qrSize', label:'Size', type:'select', options:['Small (128px)','Medium (256px)','Large (512px)','XL (1024px)'] },
        { id:'qrFg', label:'Foreground', type:'color', value:'#0F172A' },
        { id:'qrBg', label:'Background', type:'color', value:'#FFFFFF' }
      ], run:runQR },
    { id:'barcode-gen', name:'Barcode Generator', desc:'CODE128, EAN13, UPC, CODE39', cat:'util', icon:'fa-barcode',
      modes:['text'], options:[
        { id:'bcFmt', label:'Format', type:'select', options:['CODE128','EAN13','UPC','CODE39'] }
      ], run:runBarcode },
    { id:'password-gen', name:'Password Generator', desc:'Strong, customizable passwords', cat:'util', icon:'fa-key',
      modes:['text'], options:[
        { id:'len', label:'Length', type:'range', min:6, max:64, value:16 },
        { id:'low', label:'lowercase abc', type:'checkbox', checked:true },
        { id:'up',  label:'UPPERCASE ABC', type:'checkbox', checked:true },
        { id:'num', label:'Numbers 0–9', type:'checkbox', checked:true },
        { id:'sym', label:'Symbols !@#…', type:'checkbox', checked:true },
        { id:'avoid', label:'Avoid look-alikes (0/O, l/1)', type:'checkbox', checked:false }
      ], run:runPassword },
    { id:'hash-gen', name:'Hash Generator', desc:'MD5, SHA1, SHA256, SHA512', cat:'util', icon:'fa-hashtag',
      modes:['text'], options:[
        { id:'h', label:'Algorithm', type:'select', options:['MD5','SHA1','SHA256','SHA512'] }
      ], run:runHash },
    { id:'uuid-gen', name:'UUID Generator', desc:'Generate one or many UUID v4 strings', cat:'util', icon:'fa-fingerprint',
      modes:['text'], options:[
        { id:'count', label:'Quantity', type:'number', value:1, min:1, max:1000 }
      ], run:runUUID },
    { id:'lorem-gen', name:'Lorem Ipsum', desc:'Generate placeholder paragraphs', cat:'util', icon:'fa-paragraph',
      modes:['text'], options:[
        { id:'p', label:'Paragraphs', type:'number', value:3, min:1, max:50 }
      ], run:runLorem },
    { id:'color-picker', name:'Color Picker / Converter', desc:'HEX ↔ RGB ↔ HSL with palette', cat:'util', icon:'fa-eye-dropper',
      modes:['text'], options:[
        { id:'col', label:'Pick a color', type:'color', value:'#6366F1' }
      ], run:runColor },
    { id:'timestamp', name:'Timestamp Converter', desc:'Unix epoch ↔ human date', cat:'util', icon:'fa-clock',
      modes:['text'], options:[
        { id:'ts', label:'Timestamp (ms or s — blank = now)', type:'text', placeholder:'leave blank for now' }
      ], run:runTimestamp },
    { id:'unit-conv', name:'Unit Converter', desc:'Length, weight, temperature', cat:'util', icon:'fa-ruler-combined',
      modes:['text'], options:[
        { id:'cat', label:'Category', type:'select', options:['Length','Weight','Temperature'] },
        { id:'from', label:'From', type:'select', options:['Meters','Kilometers','Miles','Feet','Inches','Centimeters'] },
        { id:'to', label:'To', type:'select', options:['Meters','Kilometers','Miles','Feet','Inches','Centimeters'] },
        { id:'val', label:'Value', type:'number', value:1 }
      ], run:runUnits },
    { id:'zip-files', name:'ZIP Files', desc:'Create a .zip archive from multiple files', cat:'util', icon:'fa-file-zipper',
      modes:['file'], accept:'*', multiple:true, run:runZip },
    { id:'unzip', name:'Unzip Archive', desc:'Extract and download files from .zip', cat:'util', icon:'fa-box-open',
      modes:['file'], accept:'.zip', run:runUnzip },
    { id:'signature', name:'Signature Generator', desc:'Make a signature image from your name', cat:'util', icon:'fa-signature',
      modes:['text'], options:[
        { id:'name', label:'Your name', type:'text', placeholder:'Type your name', value:'' },
        { id:'font', label:'Style', type:'select', options:['Dancing Script','Great Vibes','Pacifico','Cursive'] },
        { id:'col', label:'Ink color', type:'color', value:'#0F172A' }
      ], run:runSignature },
    { id:'pomodoro-help', name:'Reading Time Estimator', desc:'Estimate reading time of any text', cat:'util', icon:'fa-clock-rotate-left',
      modes:['text'], options:[
        { id:'wpm', label:'Reading speed (words/min)', type:'number', value:230, min:80, max:600 }
      ], run:runReadingTime },
];

const TOOL_MAP = Object.fromEntries(TOOLS.map(t => [t.id, t]));
const CATEGORIES = ['pdf','image','doc','convert','util'];

/* ---------------- Rendering ---------------- */
function renderTool(t) {
    const isFav = state.favorites.has(t.id);
    return `
        <div class="tool" data-id="${t.id}" data-cat="${t.cat}" tabindex="0" role="button" aria-label="${t.name}">
            <div class="tool-top">
                <div class="tool-ico" aria-hidden="true"><i class="fas ${t.icon}"></i></div>
                <button class="fav-btn ${isFav ? 'is-fav' : ''}" data-fav="${t.id}" title="${isFav?'Unfavorite':'Add to favorites'}" aria-label="${isFav?'Unfavorite':'Add to favorites'}">
                    <i class="${isFav ? 'fas' : 'far'} fa-star"></i>
                </button>
            </div>
            <div>
                <h3>${t.name}</h3>
                <p>${t.desc}</p>
            </div>
            <span class="tool-tag">${t.cat}</span>
        </div>
    `;
}

function renderAll() {
    CATEGORIES.forEach(cat => {
        const grid = document.getElementById(`${cat}-grid`);
        if (!grid) return;
        const items = TOOLS.filter(t => t.cat === cat);
        grid.innerHTML = items.map(renderTool).join('');
        document.getElementById(`cnt-${cat}`).textContent = items.length;
    });
    document.getElementById('cnt-all').textContent = TOOLS.length;
    document.getElementById('statTools').textContent = TOOLS.length;
    refreshFavorites();
    refreshRecent();
}

function refreshFavorites() {
    const section = document.getElementById('favorites-section');
    const grid = document.getElementById('favoritesGrid');
    const favs = TOOLS.filter(t => state.favorites.has(t.id));
    document.getElementById('cnt-favorites').textContent = favs.length;
    if (!favs.length) {
        section.classList.add('is-hidden');
        return;
    }
    section.classList.remove('is-hidden');
    grid.innerHTML = favs.map(renderTool).join('');
    document.getElementById('favoritesMeta').textContent = favs.length + ' saved';
}

function refreshRecent() {
    const section = document.getElementById('recent-section');
    const grid = document.getElementById('recentGrid');
    const items = state.recent.map(id => TOOL_MAP[id]).filter(Boolean);
    document.getElementById('cnt-recent').textContent = items.length;
    if (!items.length) {
        section.classList.add('is-hidden');
        return;
    }
    section.classList.remove('is-hidden');
    grid.innerHTML = items.map(renderTool).join('');
    document.getElementById('recentMeta').textContent = items.length + ' tools';
}

/* ---------------- Theme ---------------- */
function applyTheme() {
    let theme = state.theme;
    if (theme === 'system') {
        theme = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    document.documentElement.dataset.theme = theme;
    document.querySelector('#themeToggle i').className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    document.querySelectorAll('#themeSelect .theme-btn').forEach(b => {
        b.classList.toggle('is-active', b.dataset.theme === state.theme);
    });
}
function setTheme(t) {
    state.theme = t;
    localStorage.setItem(STORAGE.theme, t);
    applyTheme();
}
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    if (state.theme === 'system') applyTheme();
});

/* ---------------- Filtering / Search ---------------- */
const fuzzy = (q, txt) => {
    q = q.toLowerCase().trim();
    txt = txt.toLowerCase();
    if (!q) return true;
    let i = 0;
    for (const ch of txt) { if (ch === q[i]) i++; if (i === q.length) return true; }
    return txt.includes(q);
};

function applyFilter() {
    const q = document.getElementById('searchInput').value.trim();
    const cat = document.querySelector('.cat-pill.is-active').dataset.cat;

    document.getElementById('searchClear').classList.toggle('is-visible', q.length > 0);

    const hasQuery = q.length > 0;
    let totalVisible = 0;

    document.querySelectorAll('.tool').forEach(el => {
        const t = TOOL_MAP[el.dataset.id];
        if (!t) return;
        const matchesQuery = !hasQuery || fuzzy(q, t.name) || fuzzy(q, t.desc);
        let matchesCat = true;
        if (cat === 'favorites') matchesCat = state.favorites.has(t.id);
        else if (cat === 'recent') matchesCat = state.recent.includes(t.id);
        else if (cat !== 'all') matchesCat = t.cat === cat;
        const visible = matchesQuery && matchesCat;
        el.classList.toggle('is-hidden', !visible);
        if (visible) totalVisible++;
    });

    // Hide whole sections that have no visible tool when filtering
    CATEGORIES.forEach(c => {
        const sec = document.getElementById(`${c}-section`);
        if (!sec) return;
        const visibleInside = sec.querySelectorAll('.tool:not(.is-hidden)').length;
        if (cat === 'all') sec.classList.toggle('is-hidden', visibleInside === 0 && hasQuery);
        else sec.classList.toggle('is-hidden', cat !== c && cat !== 'all' && !(cat==='favorites' || cat==='recent'));
    });

    // Favorites/recent sections
    const favSec = document.getElementById('favorites-section');
    const recSec = document.getElementById('recent-section');

    if (cat === 'favorites') {
        // hide everything except favorites
        CATEGORIES.forEach(c => document.getElementById(`${c}-section`)?.classList.add('is-hidden'));
        recSec.classList.add('is-hidden');
        favSec.classList.toggle('is-hidden', favSec.querySelectorAll('.tool:not(.is-hidden)').length === 0);
        if (state.favorites.size === 0) {
            document.getElementById('favoritesGrid').innerHTML = emptyHTML('No favorites yet','Tap the star on any tool card to add it here.');
            favSec.classList.remove('is-hidden');
        }
    } else if (cat === 'recent') {
        CATEGORIES.forEach(c => document.getElementById(`${c}-section`)?.classList.add('is-hidden'));
        favSec.classList.add('is-hidden');
        recSec.classList.toggle('is-hidden', recSec.querySelectorAll('.tool:not(.is-hidden)').length === 0);
        if (state.recent.length === 0) {
            document.getElementById('recentGrid').innerHTML = emptyHTML('No recent tools','Tools you open will appear here for fast re-access.');
            recSec.classList.remove('is-hidden');
        }
    } else {
        if (state.favorites.size > 0 && (cat === 'all' || cat === 'favorites')) {
            // keep favorites visible on All
            if (cat === 'all' && !hasQuery) favSec.classList.remove('is-hidden');
            else favSec.classList.add('is-hidden');
        } else { favSec.classList.add('is-hidden'); }

        if (state.recent.length > 0 && cat === 'all' && !hasQuery) recSec.classList.remove('is-hidden');
        else recSec.classList.add('is-hidden');
    }
}

function emptyHTML(title, sub) {
    return `<div class="empty-state"><i class="fas fa-magnifying-glass"></i><h3>${title}</h3><p>${sub}</p></div>`;
}

/* ---------------- Modal ---------------- */
const modal = document.getElementById('toolModal');
const settingsModal = document.getElementById('settingsModal');

function openTool(id) {
    const t = TOOL_MAP[id];
    if (!t) return;
    state.currentTool = t;

    // record recent
    state.recent = [id, ...state.recent.filter(x => x !== id)].slice(0, 6);
    saveJSON(STORAGE.recent, state.recent);

    // usage today
    if (state.usage.date !== today()) state.usage = { date: today(), count: 0 };
    state.usage.count++;
    saveJSON(STORAGE.usage, state.usage);
    document.getElementById('statUsed').textContent = state.usage.count;

    // header
    document.getElementById('modalTitle').textContent = t.name;
    document.getElementById('modalDescription').textContent = t.desc;
    document.getElementById('modalIcon').innerHTML = `<i class="fas ${t.icon}"></i>`;

    // mode resolution
    const modes = t.modes && t.modes.length ? t.modes : ['file'];
    const modeToggle = document.getElementById('modeToggle');
    const fileMode = document.getElementById('fileMode');
    const textMode = document.getElementById('textMode');
    modeToggle.classList.remove('is-visible');
    fileMode.style.display = 'none';
    textMode.classList.remove('is-active');

    if (modes.length === 1 && modes[0] === 'file') {
        fileMode.style.display = '';
    } else if (modes.length === 1 && modes[0] === 'text') {
        textMode.classList.add('is-active');
    } else if (modes.includes('both')) {
        modeToggle.classList.add('is-visible');
        // default to text
        document.querySelectorAll('.mode-btn').forEach(b => b.classList.toggle('is-active', b.dataset.mode === 'text'));
        textMode.classList.add('is-active');
        fileMode.style.display = 'none';
    }

    // file input setup
    const fileInput = document.getElementById('fileInput');
    fileInput.accept = t.accept || '*';
    fileInput.multiple = !!t.multiple;
    document.getElementById('supportedFormats').textContent = describeAccept(t.accept);

    // options
    buildOptions(t.options || []);

    // reset
    resetToolUI();
    document.getElementById('processBtnLabel').textContent = (modes[0] === 'text' || t.modes.includes('text')) ? 'Run' : 'Process';

    modal.classList.add('is-open');
    document.body.style.overflow = 'hidden';
    setTimeout(() => {
        const focusEl = (textMode.classList.contains('is-active') ? document.getElementById('textInput') : document.getElementById('uploadArea'));
        focusEl?.focus();
    }, 80);

    refreshFavorites();
    refreshRecent();
}

function closeModal() {
    modal.classList.remove('is-open');
    document.body.style.overflow = '';
    state.currentTool = null;
}

function describeAccept(a) {
    if (!a || a === '*') return 'any file type';
    if (a === 'image/*') return 'images (JPG, PNG, WEBP, GIF…)';
    if (a === 'application/pdf') return 'PDF files';
    if (a === '.zip') return 'ZIP archives';
    return a;
}

function buildOptions(options) {
    const panel = document.getElementById('optionsPanel');
    panel.innerHTML = '';
    if (!options.length) { panel.classList.remove('is-visible'); return; }
    panel.classList.add('is-visible');

    const grid = document.createElement('div');
    grid.className = 'options-grid';
    options.forEach(opt => {
        const field = document.createElement('div');
        field.className = 'field';

        if (opt.type === 'checkbox') {
            const row = document.createElement('label');
            row.className = 'check-row';
            const cb = document.createElement('input');
            cb.type = 'checkbox'; cb.id = opt.id; cb.checked = !!opt.checked;
            const span = document.createElement('span');
            span.textContent = opt.label;
            row.appendChild(cb); row.appendChild(span);
            field.appendChild(row);
        } else {
            const lab = document.createElement('label');
            lab.setAttribute('for', opt.id);
            lab.textContent = opt.label;
            field.appendChild(lab);

            if (opt.type === 'select') {
                const sel = document.createElement('select'); sel.id = opt.id;
                opt.options.forEach(o => {
                    const op = document.createElement('option'); op.value = o; op.textContent = o; sel.appendChild(op);
                });
                if (opt.value !== undefined) sel.value = opt.value;
                field.appendChild(sel);
            } else if (opt.type === 'range') {
                const row = document.createElement('div'); row.className = 'range-row';
                const inp = document.createElement('input');
                inp.type = 'range'; inp.id = opt.id;
                inp.min = opt.min ?? 0; inp.max = opt.max ?? 100; inp.value = opt.value ?? 50;
                const val = document.createElement('span'); val.className = 'range-val';
                val.textContent = inp.value + (opt.suffix || '');
                inp.addEventListener('input', () => val.textContent = inp.value + (opt.suffix || ''));
                row.appendChild(inp); row.appendChild(val);
                field.appendChild(row);
            } else if (opt.type === 'color') {
                const inp = document.createElement('input');
                inp.type = 'color'; inp.id = opt.id; inp.value = opt.value || '#6366F1';
                field.appendChild(inp);
            } else {
                const inp = document.createElement('input');
                inp.type = opt.type; inp.id = opt.id;
                if (opt.placeholder) inp.placeholder = opt.placeholder;
                if (opt.value !== undefined) inp.value = opt.value;
                if (opt.min !== undefined) inp.min = opt.min;
                if (opt.max !== undefined) inp.max = opt.max;
                field.appendChild(inp);
            }
        }

        grid.appendChild(field);
    });
    panel.appendChild(grid);
}

function resetToolUI() {
    state.files = [];
    document.getElementById('fileList').classList.remove('is-visible');
    document.getElementById('fileList').innerHTML = '';
    document.getElementById('textInput').value = '';
    document.getElementById('progressEl').classList.remove('is-visible');
    document.getElementById('outputEl').classList.remove('is-visible');
    document.getElementById('successEl').classList.remove('is-visible');
    document.getElementById('outputContent').innerHTML = '';
    document.getElementById('progressFill').style.width = '0%';
    document.getElementById('processBtn').disabled = false;
}

/* ---------------- Files ---------------- */
function handleFiles(list) {
    const t = state.currentTool;
    if (!t) return;
    const arr = Array.from(list);
    if (!t.multiple && arr.length > 1) { toast('warn','Single file','This tool accepts one file at a time'); arr.length = 1; }
    state.files = arr;
    drawFileList();
}

function drawFileList() {
    const wrap = document.getElementById('fileList');
    if (!state.files.length) { wrap.classList.remove('is-visible'); return; }
    wrap.classList.add('is-visible');
    wrap.innerHTML = state.files.map((f,i) => `
        <div class="file-item">
            <div class="file-ico"><i class="fas ${fileIcon(f.type, f.name)}"></i></div>
            <div class="file-info">
                <div class="file-name">${escapeHtml(f.name)}</div>
                <div class="file-size">${formatBytes(f.size)} · ${escapeHtml(f.type || 'unknown')}</div>
            </div>
            <button class="file-remove" data-remove="${i}" aria-label="Remove file"><i class="fas fa-times"></i></button>
        </div>
    `).join('');
}

function fileIcon(type, name) {
    type = type || '';
    if (type.includes('pdf') || name.endsWith('.pdf')) return 'fa-file-pdf';
    if (type.startsWith('image/')) return 'fa-file-image';
    if (type.includes('zip') || name.endsWith('.zip')) return 'fa-file-zipper';
    if (type.includes('word') || /\.docx?$/.test(name)) return 'fa-file-word';
    if (type.includes('excel') || type.includes('sheet') || /\.xlsx?$/.test(name) || name.endsWith('.csv')) return 'fa-file-excel';
    if (type.includes('text') || /\.(txt|md|log|json|xml|csv)$/i.test(name)) return 'fa-file-lines';
    return 'fa-file';
}

function formatBytes(n) {
    if (!n) return '0 B';
    const k = 1024;
    const u = ['B','KB','MB','GB'];
    const i = Math.min(u.length-1, Math.floor(Math.log(n) / Math.log(k)));
    return (n/Math.pow(k,i)).toFixed(i ? 1 : 0) + ' ' + u[i];
}

function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

/* ---------------- Run / Progress / Output ---------------- */
function progress(pct, text = 'Processing…') {
    document.getElementById('progressEl').classList.add('is-visible');
    document.getElementById('progressFill').style.width = pct + '%';
    document.getElementById('progressText').textContent = text;
    document.getElementById('progressPct').textContent = Math.round(pct) + '%';
}

function showText(text) {
    const out = document.getElementById('outputEl');
    const content = document.getElementById('outputContent');
    content.innerHTML = `<pre id="outPre"></pre>`;
    document.getElementById('outPre').textContent = text;
    out.classList.add('is-visible');
    document.getElementById('progressEl').classList.remove('is-visible');
    document.getElementById('processBtn').disabled = false;
    // copy/save
    document.getElementById('copyOutBtn').onclick = () => {
        navigator.clipboard.writeText(text).then(() => toast('success','Copied','Result copied to clipboard'));
    };
    document.getElementById('downloadTextBtn').onclick = () => {
        downloadBlob(new Blob([text], {type:'text/plain'}), 'result.txt');
    };
}

function showImage(blob, downloadName) {
    const url = URL.createObjectURL(blob);
    const out = document.getElementById('outputEl');
    document.getElementById('outputContent').innerHTML = `<div class="output-img-wrap"><img alt="result" src="${url}" /></div>`;
    out.classList.add('is-visible');
    document.getElementById('progressEl').classList.remove('is-visible');
    document.getElementById('processBtn').disabled = false;
    document.getElementById('copyOutBtn').onclick = () => copyImageToClipboard(blob);
    document.getElementById('downloadTextBtn').onclick = () => downloadBlob(blob, downloadName || 'image.png');
    showSuccess(blob, downloadName || 'image.png');
}

function showSuccess(blob, filename) {
    document.getElementById('progressEl').classList.remove('is-visible');
    const s = document.getElementById('successEl');
    s.classList.add('is-visible');
    document.getElementById('successMessage').textContent = filename + ' · ' + formatBytes(blob.size);
    document.getElementById('downloadBtn').onclick = () => downloadBlob(blob, filename);
    document.getElementById('processBtn').disabled = false;
    toast('success','Done!','Your file is ready');
}

function downloadBlob(blob, name) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function copyImageToClipboard(blob) {
    try {
        if (navigator.clipboard && window.ClipboardItem) {
            await navigator.clipboard.write([new ClipboardItem({ [blob.type || 'image/png']: blob })]);
            toast('success','Copied','Image copied to clipboard');
        } else { toast('warn','Unsupported','Your browser does not support image clipboard'); }
    } catch (e) { toast('danger','Could not copy', e.message); }
}

/* ---------------- Toasts ---------------- */
let toastSeq = 0;
function toast(type, title, desc) {
    if (!state.toasts) return;
    const host = document.getElementById('toastHost');
    const id = ++toastSeq;
    const ico = { success:'fa-check', warn:'fa-triangle-exclamation', danger:'fa-circle-exclamation', info:'fa-info' }[type] || 'fa-info';
    const el = document.createElement('div');
    el.className = 'toast ' + type;
    el.dataset.id = id;
    el.innerHTML = `
        <div class="ico"><i class="fas ${ico}"></i></div>
        <div class="msg"><div class="ttl">${escapeHtml(title)}</div>${desc ? `<div class="desc">${escapeHtml(desc)}</div>`:''}</div>
        <button class="x" aria-label="dismiss"><i class="fas fa-times"></i></button>
    `;
    el.querySelector('.x').onclick = () => removeToast(el);
    host.appendChild(el);
    setTimeout(() => removeToast(el), 4200);
}
function removeToast(el) {
    if (!el || !el.parentNode) return;
    el.classList.add('is-leaving');
    setTimeout(() => el.remove(), 240);
}

/* ---------------- Run handler ---------------- */
async function runCurrent() {
    const t = state.currentTool; if (!t) return;
    const usingText = document.getElementById('textMode').classList.contains('is-active');

    if (usingText) {
        if (!document.getElementById('textInput').value.trim()) {
            toast('warn','Empty input','Please enter some text');
            return;
        }
    } else {
        if (!state.files.length) {
            toast('warn','No file','Please select a file first');
            return;
        }
    }

    // Reset prior result UI
    document.getElementById('outputEl').classList.remove('is-visible');
    document.getElementById('successEl').classList.remove('is-visible');
    document.getElementById('processBtn').disabled = true;
    progress(5, 'Starting…');

    try {
        await t.run(usingText);
    } catch (err) {
        console.error(err);
        toast('danger','Something went wrong', err.message || 'See console for details');
        document.getElementById('progressEl').classList.remove('is-visible');
        document.getElementById('processBtn').disabled = false;
    }
}

/* ---------------- Helper utils for tools ---------------- */
function $val(id, def) { const el = document.getElementById(id); return el ? el.value : def; }
function $num(id, def) { const v = parseFloat($val(id, def)); return Number.isFinite(v) ? v : def; }
function $checked(id, def = false) { const el = document.getElementById(id); return el ? el.checked : def; }
function $text() { return document.getElementById('textInput').value; }

async function loadImageFromFile(file) {
    return await createImageBitmap(file);
}

/* ============================================================
   TOOL IMPLEMENTATIONS
   ============================================================ */

/* ----- PDF ----- */
async function runMergePDF() {
    const { PDFDocument } = PDFLib;
    progress(15, 'Loading PDFs…');
    const merged = await PDFDocument.create();
    for (let i = 0; i < state.files.length; i++) {
        progress(15 + (i/state.files.length)*70, `Merging ${i+1}/${state.files.length}…`);
        const bytes = await state.files[i].arrayBuffer();
        const pdf = await PDFDocument.load(bytes, { ignoreEncryption: true });
        const pages = await merged.copyPages(pdf, pdf.getPageIndices());
        pages.forEach(p => merged.addPage(p));
    }
    progress(95, 'Saving…');
    const out = await merged.save();
    progress(100, 'Done');
    showSuccess(new Blob([out], { type: 'application/pdf' }), 'merged.pdf');
}

async function runSplitPDF() {
    const { PDFDocument } = PDFLib;
    const mode = $val('splitMode','Each page');
    const step = mode === 'Each page' ? 1 : (mode === 'Every 2 pages' ? 2 : 3);
    progress(10, 'Reading PDF…');
    const file = state.files[0];
    const pdf = await PDFDocument.load(await file.arrayBuffer(), { ignoreEncryption: true });
    const count = pdf.getPageCount();
    const zip = new JSZip();
    for (let i = 0; i < count; i += step) {
        progress(10 + (i/count)*80, `Page ${i+1}/${count}`);
        const part = await PDFDocument.create();
        const idxs = [];
        for (let j = i; j < Math.min(i+step, count); j++) idxs.push(j);
        const pages = await part.copyPages(pdf, idxs);
        pages.forEach(p => part.addPage(p));
        const bytes = await part.save();
        zip.file(`pages_${i+1}-${Math.min(i+step,count)}.pdf`, bytes);
    }
    progress(95, 'Packing…');
    const blob = await zip.generateAsync({ type:'blob' });
    progress(100,'Done');
    showSuccess(blob, 'split_pdf.zip');
}

async function runCompressPDF() {
    const { PDFDocument } = PDFLib;
    progress(20, 'Re-saving (compressed)…');
    const file = state.files[0];
    const pdf = await PDFDocument.load(await file.arrayBuffer(), { ignoreEncryption: true });
    // best-effort: re-save trims streams a bit
    pdf.setTitle(pdf.getTitle() || file.name);
    pdf.setProducer('Fimro Flow');
    const bytes = await pdf.save({ useObjectStreams: true });
    progress(100, 'Done');
    const blob = new Blob([bytes], { type:'application/pdf' });
    showSuccess(blob, 'compressed_' + file.name);
}

async function runRotatePDF() {
    const { PDFDocument, degrees } = PDFLib;
    const rot = $val('rot','90° Clockwise');
    const deg = rot === '180°' ? 180 : (rot === '90° Counter-clockwise' ? -90 : 90);
    progress(20, 'Rotating pages…');
    const file = state.files[0];
    const pdf = await PDFDocument.load(await file.arrayBuffer(), { ignoreEncryption: true });
    pdf.getPages().forEach(p => p.setRotation(degrees(((p.getRotation().angle||0)+deg+360)%360)));
    const bytes = await pdf.save();
    progress(100,'Done');
    showSuccess(new Blob([bytes], { type:'application/pdf' }), 'rotated_' + file.name);
}

async function runOrganizePDF() {
    const { PDFDocument } = PDFLib;
    const order = $val('order','').trim();
    progress(15,'Loading…');
    const file = state.files[0];
    const src = await PDFDocument.load(await file.arrayBuffer(), { ignoreEncryption: true });
    const total = src.getPageCount();
    let indices;
    if (!order) indices = Array.from({length: total}, (_,i)=>total-1-i);
    else indices = order.split(',').map(s => parseInt(s.trim(),10)-1).filter(n => n>=0 && n<total);
    if (!indices.length) throw new Error('Empty page list');
    const out = await PDFDocument.create();
    const pages = await out.copyPages(src, indices);
    pages.forEach(p => out.addPage(p));
    const bytes = await out.save();
    progress(100,'Done');
    showSuccess(new Blob([bytes], {type:'application/pdf'}), 'organized_' + file.name);
}

async function runPDFToImages() {
    // Without pdf.js this is limited; produce a single page render via embedded preview is not feasible.
    // Use pdf-lib to render each page count then provide a friendly notice with text export fallback for browsers without pdf.js.
    // Implement a basic rasterizer using <canvas> via pdf-lib's getPageCount + render with text fallback.
    const { PDFDocument } = PDFLib;
    const fmt = $val('imgFmt','PNG');
    progress(20, 'Loading…');
    const pdf = await PDFDocument.load(await state.files[0].arrayBuffer(), { ignoreEncryption: true });
    const count = pdf.getPageCount();
    const zip = new JSZip();
    for (let i = 0; i < count; i++) {
        progress(20 + (i/count)*70, `Rendering ${i+1}/${count}`);
        // Render as a single-page PDF blob (browser can still preview it). Save bytes as fallback.
        const single = await PDFDocument.create();
        const [p] = await single.copyPages(pdf, [i]);
        single.addPage(p);
        const bytes = await single.save();
        // Use the page size to draw a placeholder canvas with metadata since true rasterization needs pdf.js
        const { width, height } = p.getSize();
        const canvas = document.createElement('canvas');
        const scale = 2;
        canvas.width = Math.round(width*scale);
        canvas.height = Math.round(height*scale);
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fff'; ctx.fillRect(0,0,canvas.width,canvas.height);
        ctx.fillStyle = '#0F172A';
        ctx.font = `${24*scale}px Inter, sans-serif`;
        ctx.fillText(`Page ${i+1} of ${count}`, 30, 50);
        ctx.font = `${14*scale}px Inter, sans-serif`;
        ctx.fillStyle = '#64748B';
        ctx.fillText(`${state.files[0].name}`, 30, 90);
        ctx.fillText(`Size: ${width.toFixed(0)} × ${height.toFixed(0)}`, 30, 120);
        ctx.fillText('Note: Full rasterization requires pdf.js — exporting page-as-PDF inside the ZIP.', 30, 160);
        const blob = await new Promise(r => canvas.toBlob(r, fmt === 'JPG' ? 'image/jpeg' : 'image/png', 0.9));
        zip.file(`page_${i+1}.${fmt.toLowerCase()}`, blob);
        zip.file(`page_${i+1}.pdf`, bytes);
    }
    progress(95, 'Packing…');
    const out = await zip.generateAsync({ type:'blob' });
    progress(100,'Done');
    showSuccess(out, 'pdf_pages.zip');
}

async function runPDFToText() {
    const { PDFDocument } = PDFLib;
    progress(20,'Reading…');
    const pdf = await PDFDocument.load(await state.files[0].arrayBuffer(), { ignoreEncryption: true });
    const meta = [
        `Title: ${pdf.getTitle() || '—'}`,
        `Author: ${pdf.getAuthor() || '—'}`,
        `Pages: ${pdf.getPageCount()}`,
        ``,
        `(Note: full text extraction needs pdf.js — metadata + structure shown.)`
    ].join('\n');
    progress(100,'Done');
    showText(meta);
}

async function runPDFToCSV() {
    const { PDFDocument } = PDFLib;
    const pdf = await PDFDocument.load(await state.files[0].arrayBuffer(), { ignoreEncryption: true });
    const rows = [['Page','Width','Height','Rotation']];
    pdf.getPages().forEach((p, i) => rows.push([i+1, p.getWidth().toFixed(0), p.getHeight().toFixed(0), p.getRotation().angle || 0]));
    const csv = rows.map(r => r.join(',')).join('\n');
    progress(100,'Done');
    showText(csv);
}

async function runProtectPDF() {
    // pdf-lib does not support encryption. We add a watermark + metadata note as best-effort.
    const { PDFDocument, rgb, StandardFonts } = PDFLib;
    const pwd = $val('pwd','');
    if (!pwd) throw new Error('Please enter a password');
    progress(20, 'Marking…');
    const pdf = await PDFDocument.load(await state.files[0].arrayBuffer(), { ignoreEncryption: true });
    pdf.setSubject('Password-protected (Fimro Flow soft-lock)');
    pdf.setKeywords([`ff-pwd-hash:${CryptoJS.SHA256(pwd).toString().slice(0,16)}`]);
    // Visible mark
    const font = await pdf.embedFont(StandardFonts.HelveticaBold);
    pdf.getPages().forEach(p => {
        p.drawText('🔒 Protected', { x: 20, y: 20, size: 10, font, color: rgb(.95,.2,.2), opacity: .35 });
    });
    const bytes = await pdf.save();
    toast('info','Soft-lock applied','True encryption requires server-side. A visible mark + metadata hash were added.');
    progress(100,'Done');
    showSuccess(new Blob([bytes], {type:'application/pdf'}), 'protected_' + state.files[0].name);
}

async function runUnlockPDF() {
    const { PDFDocument } = PDFLib;
    progress(20,'Opening…');
    try {
        const pdf = await PDFDocument.load(await state.files[0].arrayBuffer(), { ignoreEncryption: true });
        const bytes = await pdf.save();
        progress(100,'Done');
        showSuccess(new Blob([bytes], {type:'application/pdf'}), 'unlocked_' + state.files[0].name);
        toast('info','Re-saved','File re-saved without restriction flags. Hard-encrypted PDFs may not open without their password.');
    } catch (e) {
        throw new Error('Could not open this PDF. It may be hard-encrypted.');
    }
}

async function runImagesToPDF() {
    const { PDFDocument } = PDFLib;
    const pageSize = $val('pageSize','Fit image');
    progress(15,'Creating PDF…');
    const pdf = await PDFDocument.create();
    for (let i = 0; i < state.files.length; i++) {
        progress(15 + (i/state.files.length)*70, `Adding ${i+1}/${state.files.length}…`);
        const file = state.files[i];
        const bytes = await file.arrayBuffer();
        let img;
        if (file.type === 'image/jpeg' || file.type === 'image/jpg') img = await pdf.embedJpg(bytes);
        else if (file.type === 'image/png') img = await pdf.embedPng(bytes);
        else {
            // re-encode using canvas
            const bitmap = await createImageBitmap(file);
            const canvas = document.createElement('canvas');
            canvas.width = bitmap.width; canvas.height = bitmap.height;
            canvas.getContext('2d').drawImage(bitmap, 0, 0);
            const png = await new Promise(r => canvas.toBlob(r, 'image/png'));
            img = await pdf.embedPng(await png.arrayBuffer());
        }
        let pageW = img.width, pageH = img.height;
        if (pageSize === 'A4') { pageW = 595; pageH = 842; }
        else if (pageSize === 'Letter') { pageW = 612; pageH = 792; }
        const page = pdf.addPage([pageW, pageH]);
        if (pageSize === 'Fit image') {
            page.drawImage(img, { x:0, y:0, width: img.width, height: img.height });
        } else {
            const r = Math.min(pageW / img.width, pageH / img.height);
            const w = img.width * r, h = img.height * r;
            page.drawImage(img, { x:(pageW-w)/2, y:(pageH-h)/2, width: w, height: h });
        }
    }
    const bytes = await pdf.save();
    progress(100,'Done');
    showSuccess(new Blob([bytes], { type:'application/pdf' }), 'images.pdf');
}

async function runTextToPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: 'pt', format: 'a4' });
    const fontSize = $num('fontSize',12);
    doc.setFontSize(fontSize);
    const text = $text();
    const margin = 50;
    const lines = doc.splitTextToSize(text, doc.internal.pageSize.getWidth() - margin*2);
    let y = margin + fontSize;
    const pageH = doc.internal.pageSize.getHeight();
    for (const ln of lines) {
        if (y > pageH - margin) { doc.addPage(); y = margin + fontSize; }
        doc.text(ln, margin, y);
        y += fontSize * 1.4;
    }
    const blob = doc.output('blob');
    progress(100,'Done');
    showSuccess(blob, 'text.pdf');
}

/* ----- Image helpers ----- */
async function withCanvas(file, fn) {
    const img = await loadImageFromFile(file);
    const canvas = document.createElement('canvas');
    return fn(canvas, img);
}
function canvasToBlobAsync(canvas, type = 'image/png', q = 0.92) {
    return new Promise(r => canvas.toBlob(r, type, q));
}

async function runImageCompress() {
    progress(25,'Compressing…');
    const q = $num('q', 80) / 100;
    const file = state.files[0];
    const blob = await withCanvas(file, async (canvas, img) => {
        canvas.width = img.width; canvas.height = img.height;
        canvas.getContext('2d').drawImage(img,0,0);
        return await canvasToBlobAsync(canvas, file.type.includes('png') ? 'image/jpeg' : (file.type || 'image/jpeg'), q);
    });
    progress(100,'Done');
    showImage(blob, 'compressed_' + file.name.replace(/\.[^.]+$/, '.jpg'));
}

async function runImageResize() {
    progress(25,'Resizing…');
    const w = $num('w',800), h = $num('h',600), keep = $checked('keep',true);
    const file = state.files[0];
    const blob = await withCanvas(file, async (canvas, img) => {
        let tw = w, th = h;
        if (keep) {
            const r = Math.min(w/img.width, h/img.height);
            tw = Math.round(img.width*r); th = Math.round(img.height*r);
        }
        canvas.width = tw; canvas.height = th;
        const ctx = canvas.getContext('2d');
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, tw, th);
        return await canvasToBlobAsync(canvas, file.type || 'image/png');
    });
    progress(100,'Done');
    showImage(blob, 'resized_' + file.name);
}

async function runImageCrop() {
    progress(25,'Cropping…');
    const x = $num('x',0), y = $num('y',0), cw = $num('cw',400), ch = $num('ch',400);
    const file = state.files[0];
    const blob = await withCanvas(file, async (canvas, img) => {
        canvas.width = cw; canvas.height = ch;
        canvas.getContext('2d').drawImage(img, x, y, cw, ch, 0, 0, cw, ch);
        return await canvasToBlobAsync(canvas, file.type || 'image/png');
    });
    progress(100,'Done');
    showImage(blob, 'cropped_' + file.name);
}

async function runImageRotate() {
    progress(25,'Rotating…');
    const angleStr = $val('angle','90° Clockwise');
    const custom = $num('custom', 45);
    let deg = angleStr === '180°' ? 180 : angleStr === '90° Counter-clockwise' ? -90 : angleStr === 'Custom' ? custom : 90;
    const rad = (deg * Math.PI) / 180;
    const file = state.files[0];
    const blob = await withCanvas(file, async (canvas, img) => {
        const sin = Math.abs(Math.sin(rad)), cos = Math.abs(Math.cos(rad));
        canvas.width = Math.round(img.width*cos + img.height*sin);
        canvas.height = Math.round(img.width*sin + img.height*cos);
        const ctx = canvas.getContext('2d');
        ctx.translate(canvas.width/2, canvas.height/2);
        ctx.rotate(rad);
        ctx.drawImage(img, -img.width/2, -img.height/2);
        return await canvasToBlobAsync(canvas, file.type || 'image/png');
    });
    progress(100,'Done');
    showImage(blob, 'rotated_' + file.name);
}

async function runImageFlip() {
    progress(25,'Flipping…');
    const dir = $val('dir','Horizontal');
    const file = state.files[0];
    const blob = await withCanvas(file, async (canvas, img) => {
        canvas.width = img.width; canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        let sx = 1, sy = 1, tx = 0, ty = 0;
        if (dir === 'Horizontal' || dir === 'Both') { sx = -1; tx = canvas.width; }
        if (dir === 'Vertical'   || dir === 'Both') { sy = -1; ty = canvas.height; }
        ctx.translate(tx, ty); ctx.scale(sx, sy);
        ctx.drawImage(img, 0, 0);
        return await canvasToBlobAsync(canvas, file.type || 'image/png');
    });
    progress(100,'Done');
    showImage(blob, 'flipped_' + file.name);
}

async function runImageConvert() {
    progress(25,'Converting…');
    const fmt = $val('fmt','PNG');
    const map = { JPG:'image/jpeg', PNG:'image/png', WEBP:'image/webp', BMP:'image/bmp' };
    const file = state.files[0];
    const blob = await withCanvas(file, async (canvas, img) => {
        canvas.width = img.width; canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (fmt === 'JPG') { ctx.fillStyle = '#FFFFFF'; ctx.fillRect(0,0,canvas.width,canvas.height); }
        ctx.drawImage(img,0,0);
        return await canvasToBlobAsync(canvas, map[fmt], 0.92);
    });
    const name = file.name.replace(/\.[^.]+$/, '') + '.' + fmt.toLowerCase();
    progress(100,'Done');
    showImage(blob, name);
}

async function runImageFilter() {
    progress(25,'Applying filter…');
    const f = $val('flt','Grayscale');
    const map = {
        'Grayscale':'grayscale(100%)','Sepia':'sepia(100%)','Blur':'blur(6px)',
        'Invert':'invert(100%)','Brightness +':'brightness(150%)','Contrast +':'contrast(150%)','Saturate +':'saturate(200%)'
    };
    const file = state.files[0];
    const blob = await withCanvas(file, async (canvas, img) => {
        canvas.width = img.width; canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        ctx.filter = map[f];
        ctx.drawImage(img, 0, 0);
        return await canvasToBlobAsync(canvas, file.type || 'image/png');
    });
    progress(100,'Done');
    showImage(blob, 'filtered_' + file.name);
}

async function runPhotoEditor() {
    progress(25,'Editing…');
    const b = $num('b',100), c = $num('c',100), s = $num('s',100);
    const file = state.files[0];
    const blob = await withCanvas(file, async (canvas, img) => {
        canvas.width = img.width; canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        ctx.filter = `brightness(${b}%) contrast(${c}%) saturate(${s}%)`;
        ctx.drawImage(img,0,0);
        return await canvasToBlobAsync(canvas, file.type || 'image/png');
    });
    progress(100,'Done');
    showImage(blob, 'edited_' + file.name);
}

async function runWatermark() {
    progress(25,'Adding watermark…');
    const text = $val('text','© Watermark');
    const op = $num('op',50)/100;
    const pos = $val('pos','Center');
    const file = state.files[0];
    const blob = await withCanvas(file, async (canvas, img) => {
        canvas.width = img.width; canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img,0,0);
        const size = Math.max(20, Math.round(Math.min(img.width,img.height)/14));
        ctx.font = `bold ${size}px Inter, sans-serif`;
        ctx.fillStyle = `rgba(255,255,255,${op})`;
        ctx.strokeStyle = `rgba(0,0,0,${op})`;
        ctx.lineWidth = Math.max(1, size/16);
        const m = ctx.measureText(text);
        const padding = size*0.6;
        let x, y;
        switch (pos) {
            case 'Center': x = img.width/2 - m.width/2; y = img.height/2 + size/3; break;
            case 'Top-left': x = padding; y = padding + size; break;
            case 'Top-right': x = img.width - m.width - padding; y = padding + size; break;
            case 'Bottom-left': x = padding; y = img.height - padding; break;
            case 'Bottom-right': x = img.width - m.width - padding; y = img.height - padding; break;
            case 'Diagonal':
                ctx.save();
                ctx.translate(img.width/2, img.height/2);
                ctx.rotate(-Math.PI/6);
                ctx.textAlign = 'center';
                ctx.strokeText(text, 0, 0);
                ctx.fillText(text, 0, 0);
                ctx.restore();
                return await canvasToBlobAsync(canvas, file.type || 'image/png');
        }
        ctx.strokeText(text, x, y);
        ctx.fillText(text, x, y);
        return await canvasToBlobAsync(canvas, file.type || 'image/png');
    });
    progress(100,'Done');
    showImage(blob, 'wm_' + file.name);
}

async function runRemoveBg() {
    progress(20,'Reading pixels…');
    const tol = $num('tol',25);
    const targetHex = $val('targetColor','').trim();
    const file = state.files[0];
    const blob = await withCanvas(file, async (canvas, img) => {
        canvas.width = img.width; canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img,0,0);
        const id = ctx.getImageData(0,0,canvas.width,canvas.height);
        let [tr, tg, tb] = [id.data[0], id.data[1], id.data[2]];
        if (/^#?[0-9a-f]{6}$/i.test(targetHex)) {
            const h = targetHex.replace('#','');
            tr = parseInt(h.slice(0,2),16); tg = parseInt(h.slice(2,4),16); tb = parseInt(h.slice(4,6),16);
        }
        const t = (tol/100) * 442;
        for (let i = 0; i < id.data.length; i += 4) {
            const dr = id.data[i]-tr, dg = id.data[i+1]-tg, db = id.data[i+2]-tb;
            const d = Math.sqrt(dr*dr+dg*dg+db*db);
            if (d <= t) id.data[i+3] = 0;
        }
        ctx.putImageData(id, 0, 0);
        return await canvasToBlobAsync(canvas, 'image/png');
    });
    progress(100,'Done');
    showImage(blob, 'nobg_' + file.name.replace(/\.[^.]+$/, '.png'));
}

async function runMeme() {
    progress(25,'Generating meme…');
    const top = $val('top',''), bot = $val('bot','');
    const file = state.files[0];
    const blob = await withCanvas(file, async (canvas, img) => {
        canvas.width = img.width; canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img,0,0);
        const size = Math.max(28, Math.round(img.width/12));
        ctx.font = `900 ${size}px Impact, "Arial Black", sans-serif`;
        ctx.textAlign = 'center';
        ctx.lineWidth = Math.max(3, size/10);
        ctx.strokeStyle = '#000'; ctx.fillStyle = '#fff';
        const draw = (text, y) => {
            const lines = wrapText(ctx, text.toUpperCase(), img.width - 40);
            lines.forEach((ln, i) => {
                const yy = y + i * size * 1.05;
                ctx.strokeText(ln, img.width/2, yy);
                ctx.fillText(ln, img.width/2, yy);
            });
        };
        if (top) draw(top, size + 12);
        if (bot) draw(bot, img.height - (bot.split('\n').length)*size*0.4 - 12);
        return await canvasToBlobAsync(canvas, 'image/jpeg', 0.92);
    });
    progress(100,'Done');
    showImage(blob, 'meme.jpg');
}
function wrapText(ctx, text, maxW) {
    const words = text.split(' ');
    const out = []; let line = '';
    for (const w of words) {
        const test = line ? line + ' ' + w : w;
        if (ctx.measureText(test).width > maxW && line) { out.push(line); line = w; }
        else line = test;
    }
    if (line) out.push(line);
    return out;
}

async function runImageInfo() {
    const file = state.files[0];
    const img = await loadImageFromFile(file);
    const canvas = document.createElement('canvas');
    const N = 40;
    canvas.width = N; canvas.height = N;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, N, N);
    const d = ctx.getImageData(0,0,N,N).data;
    let r=0,g=0,b=0;
    for (let i=0;i<d.length;i+=4){ r+=d[i]; g+=d[i+1]; b+=d[i+2]; }
    const count = d.length/4;
    r = Math.round(r/count); g = Math.round(g/count); b = Math.round(b/count);
    const hex = '#' + [r,g,b].map(n => n.toString(16).padStart(2,'0')).join('');
    const summary =
`File:        ${file.name}
Size:        ${formatBytes(file.size)}
Type:        ${file.type || 'unknown'}
Dimensions:  ${img.width} × ${img.height} px
Aspect:      ${(img.width/img.height).toFixed(3)}
Dominant:    ${hex}  rgb(${r}, ${g}, ${b})
Megapixels:  ${(img.width*img.height/1_000_000).toFixed(2)} MP`;
    showText(summary);
}

/* ----- Document text utilities ----- */
async function runWordCounter() {
    const t = $text();
    const chars = t.length;
    const noWS = t.replace(/\s/g,'').length;
    const words = (t.trim().match(/\S+/g) || []).length;
    const lines = t.split(/\n/).length;
    const sentences = (t.match(/[.!?]+/g) || []).length;
    const paragraphs = t.split(/\n{2,}/).filter(p => p.trim()).length;
    const readingMin = Math.max(1, Math.round(words / 230));
    const summary =
`Words:       ${words}
Characters:  ${chars}
No spaces:   ${noWS}
Lines:       ${lines}
Sentences:   ${sentences}
Paragraphs:  ${paragraphs}
Reading:     ~${readingMin} min`;
    showText(summary);
}

async function runTextCase() {
    const t = $text();
    const c = $val('caseType','UPPERCASE');
    let r;
    switch (c) {
        case 'UPPERCASE': r = t.toUpperCase(); break;
        case 'lowercase': r = t.toLowerCase(); break;
        case 'Title Case': r = t.replace(/\w\S*/g, w => w.charAt(0).toUpperCase()+w.slice(1).toLowerCase()); break;
        case 'Sentence case': r = t.toLowerCase().replace(/(^|[.!?]\s+)([a-z])/g, (m,p,ch)=>p+ch.toUpperCase()); break;
        case 'iNVERT cASE': r = [...t].map(ch => ch === ch.toUpperCase() ? ch.toLowerCase() : ch.toUpperCase()).join(''); break;
        case 'camelCase': r = t.toLowerCase().replace(/[^a-z0-9]+(.)/g, (_,c)=>c.toUpperCase()).replace(/^[A-Z]/, m=>m.toLowerCase()); break;
        case 'snake_case': r = t.trim().toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,''); break;
        case 'kebab-case': r = t.trim().toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,''); break;
    }
    showText(r);
}

async function runRemoveDuplicates() {
    const trim = $checked('trim',true), sortAfter = $checked('sortAfter',false);
    const lines = $text().split('\n');
    const seen = new Set();
    const out = [];
    for (let ln of lines) {
        const key = trim ? ln.trim() : ln;
        if (!seen.has(key)) { seen.add(key); out.push(ln); }
    }
    if (sortAfter) out.sort();
    showText(out.join('\n'));
}

async function runSortLines() {
    const m = $val('mode','A → Z');
    let arr = $text().split('\n');
    if (m === 'A → Z') arr.sort((a,b)=>a.localeCompare(b));
    else if (m === 'Z → A') arr.sort((a,b)=>b.localeCompare(a));
    else if (m === 'Length (short → long)') arr.sort((a,b)=>a.length-b.length);
    else if (m === 'Length (long → short)') arr.sort((a,b)=>b.length-a.length);
    else if (m === 'Random shuffle') for (let i=arr.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [arr[i],arr[j]]=[arr[j],arr[i]]; }
    showText(arr.join('\n'));
}

async function runFindReplace() {
    const find = $val('find',''); const rep = $val('rep','');
    const regex = $checked('regex'); const ci = $checked('ci');
    if (!find) { toast('warn','Empty find','Please provide a search string'); return; }
    let pattern;
    try { pattern = regex ? new RegExp(find, 'g' + (ci?'i':'')) : new RegExp(find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g' + (ci?'i':'')); }
    catch (e) { throw new Error('Invalid regex: ' + e.message); }
    const out = $text().replace(pattern, rep);
    showText(out);
}

async function runReverseText() {
    const m = $val('rmode','Characters');
    const t = $text();
    if (m === 'Characters') showText([...t].reverse().join(''));
    else if (m === 'Words') showText(t.split(/(\s+)/).reverse().join(''));
    else showText(t.split('\n').reverse().join('\n'));
}

async function runCSVJSON() {
    const dir = $val('dir','CSV → JSON');
    const t = $text().trim();
    if (dir === 'CSV → JSON') {
        const rows = t.split(/\r?\n/).filter(Boolean).map(r => r.split(','));
        const headers = rows.shift().map(h => h.trim());
        const json = rows.map(r => Object.fromEntries(headers.map((h,i)=>[h, r[i] !== undefined ? r[i].trim() : ''])));
        showText(JSON.stringify(json, null, 2));
    } else {
        let obj;
        try { obj = JSON.parse(t); } catch (e) { throw new Error('Invalid JSON'); }
        if (!Array.isArray(obj)) obj = [obj];
        const headers = [...new Set(obj.flatMap(Object.keys))];
        const lines = [headers.join(',')];
        for (const row of obj) lines.push(headers.map(h => csvEscape(row[h])).join(','));
        showText(lines.join('\n'));
    }
}
function csvEscape(v) {
    if (v === null || v === undefined) return '';
    const s = String(v);
    if (/[",\n]/.test(s)) return `"${s.replace(/"/g,'""')}"`;
    return s;
}

async function runSlugify() {
    const slug = $text().toLowerCase()
        .normalize('NFD')
        .replace(/[̀-ͯ]/g, '')
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '')
        .replace(/-+/g, '-');
    showText(slug);
}

/* ----- Converters ----- */
async function runBase64Encode(usingText) {
    if (usingText) {
        const t = $text();
        const enc = btoa(unescape(encodeURIComponent(t)));
        showText(enc);
    } else {
        const file = state.files[0];
        const reader = new FileReader();
        reader.onload = () => showText(reader.result);
        reader.readAsDataURL(file);
    }
}
async function runBase64Decode() {
    try {
        const cleaned = $text().replace(/^data:[^,]*,/,'');
        const dec = decodeURIComponent(escape(atob(cleaned)));
        showText(dec);
    } catch (e) { throw new Error('Invalid Base64'); }
}
async function runUrlEncode() {
    const a = $val('action','Encode');
    showText(a === 'Encode' ? encodeURIComponent($text()) : decodeURIComponent($text()));
}
async function runHtmlEncode() {
    const a = $val('action','Encode');
    const t = $text();
    if (a === 'Encode') {
        showText(t.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])));
    } else {
        const div = document.createElement('div');
        div.innerHTML = t;
        showText(div.textContent || '');
    }
}
async function runHtmlToText() {
    const div = document.createElement('div');
    div.innerHTML = $text();
    showText((div.textContent || div.innerText || '').replace(/\n{3,}/g,'\n\n').trim());
}
async function runMarkdown() {
    let md = $text();
    md = md.replace(/```([\s\S]*?)```/g, (m, c) => `<pre><code>${escapeHtml(c.trim())}</code></pre>`)
        .replace(/`([^`\n]+)`/g, '<code>$1</code>')
        .replace(/^###### (.*)$/gm, '<h6>$1</h6>')
        .replace(/^##### (.*)$/gm, '<h5>$1</h5>')
        .replace(/^#### (.*)$/gm, '<h4>$1</h4>')
        .replace(/^### (.*)$/gm, '<h3>$1</h3>')
        .replace(/^## (.*)$/gm, '<h2>$1</h2>')
        .replace(/^# (.*)$/gm, '<h1>$1</h1>')
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        .replace(/(^|\W)\*(\S(?:.*?\S)?)\*(?=\W|$)/g, '$1<em>$2</em>')
        .replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img alt="$1" src="$2">')
        .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>')
        .replace(/^(\s*[-*+])\s+(.*)$/gm, '<li>$2</li>')
        .replace(/((?:^<li>.*<\/li>\n?)+)/gm, '<ul>$&</ul>')
        .replace(/\n{2,}/g, '</p><p>')
        .replace(/^(?!<h\d|<ul|<pre|<p)(.+)$/gm, '<p>$1</p>');
    showText(md);
}
async function runJsonFormat() {
    const indent = $num('indent', 2);
    const sort = $checked('sort');
    let obj;
    try { obj = JSON.parse($text()); } catch (e) { throw new Error('Invalid JSON: ' + e.message); }
    if (sort) obj = sortKeysDeep(obj);
    showText(JSON.stringify(obj, null, indent));
}
function sortKeysDeep(v) {
    if (Array.isArray(v)) return v.map(sortKeysDeep);
    if (v && typeof v === 'object') {
        return Object.keys(v).sort().reduce((a,k)=>{ a[k] = sortKeysDeep(v[k]); return a; }, {});
    }
    return v;
}
async function runXmlFormat() {
    let xml = $text().replace(/>\s*</g,'><').trim();
    let formatted = '', pad = 0;
    xml.split(/>\s*</).forEach((node, i) => {
        if (node.match(/^\/\w/)) pad--;
        formatted += (i ? '<' : '') + '  '.repeat(Math.max(0,pad)) + node + (i < xml.split('><').length-1 ? '>' : '') + '\n';
        if (node.match(/^<?\w[^>]*[^/]$/) && !node.startsWith('?')) pad++;
    });
    showText(formatted.trim());
}
async function runMinifyCSS() {
    const min = $text()
        .replace(/\/\*[\s\S]*?\*\//g,'')
        .replace(/\s+/g,' ')
        .replace(/\s*([{}:;,>+~])\s*/g,'$1')
        .replace(/;}/g,'}')
        .trim();
    showText(min);
}
async function runMinifyJS() {
    const min = $text()
        .replace(/\/\*[\s\S]*?\*\//g,'')
        .replace(/(^|[^:])\/\/[^\n]*/g,'$1')
        .replace(/\s+/g,' ')
        .replace(/\s*([{}();,=:+\-*\/<>?!&|])\s*/g,'$1')
        .trim();
    showText(min);
}

/* ----- Utilities ----- */
async function runQR() {
    const text = $text().trim();
    if (!text) throw new Error('Please enter text to encode');
    const sizeMap = { 'Small (128px)':128, 'Medium (256px)':256, 'Large (512px)':512, 'XL (1024px)':1024 };
    const size = sizeMap[$val('qrSize','Medium (256px)')];
    const fg = $val('qrFg','#0F172A'); const bg = $val('qrBg','#FFFFFF');
    progress(40,'Generating…');
    const host = document.createElement('div');
    /* eslint-disable no-new */
    new QRCode(host, { text, width: size, height: size, colorDark: fg, colorLight: bg, correctLevel: QRCode.CorrectLevel.H });
    await new Promise(r => setTimeout(r, 80));
    const canvas = host.querySelector('canvas');
    const blob = await new Promise(r => canvas.toBlob(r, 'image/png'));
    progress(100,'Done');
    showImage(blob, 'qrcode.png');
}

async function runBarcode() {
    const fmt = $val('bcFmt','CODE128');
    const data = $text().trim() || '12345678';
    progress(40,'Generating…');
    const canvas = document.createElement('canvas');
    try {
        JsBarcode(canvas, data, { format: fmt, width: 2, height: 100, displayValue: true });
    } catch (e) { throw new Error('Invalid value for ' + fmt + ': ' + e.message); }
    const blob = await new Promise(r => canvas.toBlob(r, 'image/png'));
    progress(100,'Done');
    showImage(blob, 'barcode.png');
}

async function runPassword() {
    const len = $num('len',16);
    const low = $checked('low',true), up = $checked('up',true), num = $checked('num',true), sym = $checked('sym',true);
    const avoid = $checked('avoid',false);
    let pool = '';
    if (low) pool += 'abcdefghijklmnopqrstuvwxyz';
    if (up)  pool += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (num) pool += '0123456789';
    if (sym) pool += '!@#$%^&*()_+-=[]{};:,.<>?';
    if (avoid) pool = pool.replace(/[0Oo1lI|]/g,'');
    if (!pool) throw new Error('Pick at least one character set');
    let pw = '';
    const arr = new Uint32Array(len);
    crypto.getRandomValues(arr);
    for (let i=0;i<len;i++) pw += pool[arr[i] % pool.length];
    // strength estimation
    const entropy = Math.round(Math.log2(pool.length) * len);
    let label = 'Weak';
    if (entropy >= 100) label = 'Excellent';
    else if (entropy >= 80) label = 'Strong';
    else if (entropy >= 60) label = 'Good';
    else if (entropy >= 40) label = 'Fair';
    showText(`${pw}\n\nEntropy: ~${entropy} bits (${label})`);
}

async function runHash() {
    const h = $val('h','SHA256');
    const t = $text();
    let val;
    if (h === 'MD5') val = CryptoJS.MD5(t).toString();
    else if (h === 'SHA1') val = CryptoJS.SHA1(t).toString();
    else if (h === 'SHA512') val = CryptoJS.SHA512(t).toString();
    else val = CryptoJS.SHA256(t).toString();
    showText(`${h}:\n${val}`);
}

async function runUUID() {
    const n = Math.min(1000, Math.max(1, $num('count',1)));
    const arr = [];
    for (let i=0;i<n;i++) arr.push(crypto.randomUUID());
    showText(arr.join('\n'));
}

async function runLorem() {
    const n = Math.min(50, Math.max(1, $num('p',3)));
    const lorem = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque euismod, nisl eget consectetur sagittis, nisl nunc consectetur nisi, eget consectetur nisl nisl eget nisl. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.';
    showText(Array(n).fill(lorem).join('\n\n'));
}

async function runColor() {
    const hex = $val('col','#6366F1');
    const rgb = hexToRgb(hex);
    const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
    const cmyk = rgbToCmyk(rgb.r, rgb.g, rgb.b);
    const summary =
`HEX:  ${hex}
RGB:  rgb(${rgb.r}, ${rgb.g}, ${rgb.b})
HSL:  hsl(${hsl.h}, ${hsl.s}%, ${hsl.l}%)
CMYK: cmyk(${cmyk.c}, ${cmyk.m}, ${cmyk.y}, ${cmyk.k})

Tailwind hex tokens:
  bg: bg-[${hex}]
  text: text-[${hex}]`;
    // also draw a swatch
    const canvas = document.createElement('canvas');
    canvas.width = 320; canvas.height = 120;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = hex; ctx.fillRect(0,0,canvas.width,canvas.height);
    document.getElementById('outputContent').innerHTML = `
        <div class="output-img-wrap" style="background:none;">
            <div style="display:flex; gap:1rem; align-items:center; flex-wrap:wrap;">
                <div style="width:160px;height:120px;border-radius:14px;background:${hex};box-shadow:var(--shadow-md);"></div>
                <pre style="margin:0; flex:1; min-width:180px;">${escapeHtml(summary)}</pre>
            </div>
        </div>`;
    document.getElementById('outputEl').classList.add('is-visible');
    document.getElementById('progressEl').classList.remove('is-visible');
    document.getElementById('processBtn').disabled = false;
    document.getElementById('copyOutBtn').onclick = () => navigator.clipboard.writeText(summary).then(() => toast('success','Copied','Color info copied'));
    document.getElementById('downloadTextBtn').onclick = async () => {
        const blob = await new Promise(r => canvas.toBlob(r, 'image/png'));
        downloadBlob(blob, 'color.png');
    };
}
function hexToRgb(hex) {
    const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return m ? { r: parseInt(m[1],16), g: parseInt(m[2],16), b: parseInt(m[3],16) } : { r:0,g:0,b:0 };
}
function rgbToHsl(r,g,b) {
    r/=255; g/=255; b/=255;
    const max = Math.max(r,g,b), min = Math.min(r,g,b);
    let h=0, s=0, l=(max+min)/2;
    if (max !== min) {
        const d = max-min;
        s = l > 0.5 ? d / (2-max-min) : d / (max+min);
        switch (max) {
            case r: h = (g-b)/d + (g<b?6:0); break;
            case g: h = (b-r)/d + 2; break;
            case b: h = (r-g)/d + 4; break;
        }
        h /= 6;
    }
    return { h: Math.round(h*360), s: Math.round(s*100), l: Math.round(l*100) };
}
function rgbToCmyk(r,g,b) {
    r/=255; g/=255; b/=255;
    const k = 1 - Math.max(r,g,b);
    const c = (1 - r - k) / (1 - k) || 0;
    const m = (1 - g - k) / (1 - k) || 0;
    const y = (1 - b - k) / (1 - k) || 0;
    return { c: Math.round(c*100), m: Math.round(m*100), y: Math.round(y*100), k: Math.round(k*100) };
}

async function runTimestamp() {
    let ts = $val('ts','').trim();
    let ms;
    if (!ts) ms = Date.now();
    else { const n = parseInt(ts,10); ms = ts.length <= 10 ? n*1000 : n; }
    const d = new Date(ms);
    const out =
`Unix (ms):   ${ms}
Unix (s):    ${Math.floor(ms/1000)}
Local:       ${d.toLocaleString()}
ISO 8601:    ${d.toISOString()}
UTC:         ${d.toUTCString()}
Relative:    ${relativeTime(ms - Date.now())}`;
    showText(out);
}
function relativeTime(diffMs) {
    const a = Math.abs(diffMs);
    const t = (n,u) => `${n} ${u}${n!==1?'s':''} ${diffMs<0?'ago':'from now'}`;
    if (a < 60_000) return t(Math.round(a/1000),'second');
    if (a < 3_600_000) return t(Math.round(a/60_000),'minute');
    if (a < 86_400_000) return t(Math.round(a/3_600_000),'hour');
    if (a < 2_592_000_000) return t(Math.round(a/86_400_000),'day');
    return t(Math.round(a/2_592_000_000),'month');
}

async function runUnits() {
    const cat = $val('cat','Length');
    const from = $val('from','Meters'); const to = $val('to','Kilometers');
    const v = $num('val',1);
    const length = { Meters:1, Kilometers:1000, Miles:1609.344, Feet:0.3048, Inches:0.0254, Centimeters:0.01 };
    const weight = { Kilograms:1, Grams:0.001, Pounds:0.45359237, Ounces:0.028349523125 };
    let r;
    if (cat === 'Length') r = v * (length[from]||1) / (length[to]||1);
    else if (cat === 'Weight') r = v * (weight[from]||1) / (weight[to]||1);
    else {
        let inC = v;
        if (from === 'Fahrenheit') inC = (v - 32) * 5/9;
        else if (from === 'Kelvin') inC = v - 273.15;
        r = inC;
        if (to === 'Fahrenheit') r = inC * 9/5 + 32;
        else if (to === 'Kelvin') r = inC + 273.15;
    }
    showText(`${v} ${from}  =  ${Number(r).toFixed(6).replace(/\.?0+$/,'')} ${to}`);
}

async function runZip() {
    const zip = new JSZip();
    for (let i = 0; i < state.files.length; i++) {
        progress(10 + (i/state.files.length)*70, `Adding ${i+1}/${state.files.length}`);
        zip.file(state.files[i].name, state.files[i]);
    }
    progress(95,'Compressing…');
    const blob = await zip.generateAsync({ type:'blob' });
    progress(100,'Done');
    showSuccess(blob, 'archive.zip');
}

async function runUnzip() {
    progress(20, 'Reading…');
    const zip = await JSZip.loadAsync(state.files[0]);
    const next = new JSZip();
    const entries = Object.keys(zip.files);
    for (let i=0;i<entries.length;i++) {
        progress(20 + (i/entries.length)*70, `Extracting ${i+1}/${entries.length}`);
        const f = zip.files[entries[i]];
        if (!f.dir) next.file(entries[i], await f.async('blob'));
    }
    progress(95,'Packing…');
    const blob = await next.generateAsync({ type:'blob' });
    progress(100,'Done');
    showSuccess(blob, 'extracted.zip');
}

async function runSignature() {
    const name = $val('name','').trim() || 'Signature';
    const font = $val('font','Dancing Script');
    const col = $val('col','#0F172A');
    progress(30,'Rendering…');
    const canvas = document.createElement('canvas');
    canvas.width = 800; canvas.height = 240;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0,0,canvas.width,canvas.height);
    ctx.fillStyle = col;
    const fontFamily = font === 'Cursive' ? 'cursive' : font;
    let size = 96;
    do {
        ctx.font = `400 ${size}px "${fontFamily}", cursive`;
        if (ctx.measureText(name).width <= canvas.width - 40) break;
        size -= 4;
    } while (size > 18);
    ctx.textBaseline = 'middle';
    ctx.fillText(name, 20, canvas.height/2);
    // underline
    ctx.strokeStyle = col + '55';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(20, canvas.height - 30);
    ctx.lineTo(canvas.width - 20, canvas.height - 30);
    ctx.stroke();
    const blob = await new Promise(r => canvas.toBlob(r, 'image/png'));
    progress(100,'Done');
    showImage(blob, 'signature.png');
}

async function runReadingTime() {
    const wpm = $num('wpm',230);
    const words = ($text().trim().match(/\S+/g) || []).length;
    const minutes = words / wpm;
    const mWhole = Math.floor(minutes);
    const sec = Math.round((minutes - mWhole) * 60);
    showText(`Words: ${words}\nReading speed: ${wpm} wpm\nReading time: ${mWhole} min ${sec} s\nPomodoros (25 min): ${(minutes/25).toFixed(2)}`);
}

/* ============================================================
   Wire UI
   ============================================================ */
function initEvents() {
    // Year
    document.getElementById('year').textContent = new Date().getFullYear();

    // Theme toggle
    document.getElementById('themeToggle').addEventListener('click', () => {
        const cur = document.documentElement.dataset.theme;
        setTheme(cur === 'dark' ? 'light' : 'dark');
    });
    document.querySelectorAll('#themeSelect .theme-btn').forEach(b => {
        b.addEventListener('click', () => setTheme(b.dataset.theme));
    });

    // Settings drawer
    document.getElementById('settingsBtn').addEventListener('click', openSettings);
    settingsModal.addEventListener('click', e => {
        if (e.target.dataset.close !== undefined) closeSettings();
    });

    // Switches
    bindSwitch('toastSwitch', state.toasts, v => { state.toasts = v; saveJSON(STORAGE.toasts, v); });
    bindSwitch('confirmSwitch', state.confirm, v => { state.confirm = v; saveJSON(STORAGE.confirm, v); });
    bindSwitch('auraSwitch', state.aura, v => { state.aura = v; saveJSON(STORAGE.aura, v); document.querySelector('.bg-aura').style.display = v ? '' : 'none'; });
    document.querySelector('.bg-aura').style.display = state.aura ? '' : 'none';

    document.getElementById('clearDataBtn').addEventListener('click', () => {
        if (!confirm('Clear all local data (favorites, recent, settings)?')) return;
        Object.values(STORAGE).forEach(k => localStorage.removeItem(k));
        toast('success','Cleared','Your local data has been wiped.');
        setTimeout(() => location.reload(), 600);
    });
    document.getElementById('showShortcuts').addEventListener('click', openShortcutsHelp);

    // Menu toggle
    document.getElementById('menuToggle').addEventListener('click', () => {
        document.getElementById('mainNav').classList.toggle('is-open');
    });

    // Search
    const searchInput = document.getElementById('searchInput');
    searchInput.addEventListener('input', applyFilter);
    document.getElementById('searchClear').addEventListener('click', () => { searchInput.value=''; applyFilter(); searchInput.focus(); });
    document.querySelectorAll('[data-search]').forEach(b => b.addEventListener('click', () => {
        searchInput.value = b.dataset.search; applyFilter();
        document.querySelector('.cat-pill[data-cat="all"]').click();
        searchInput.focus();
    }));

    // Category pills
    document.querySelectorAll('.cat-pill').forEach(p => p.addEventListener('click', () => {
        document.querySelectorAll('.cat-pill').forEach(x => { x.classList.remove('is-active'); x.setAttribute('aria-selected','false'); });
        p.classList.add('is-active'); p.setAttribute('aria-selected','true');
        applyFilter();
    }));

    // Tool grid clicks (delegated)
    document.addEventListener('click', e => {
        const fav = e.target.closest('[data-fav]');
        if (fav) {
            e.stopPropagation();
            const id = fav.dataset.fav;
            if (state.favorites.has(id)) state.favorites.delete(id); else state.favorites.add(id);
            saveJSON(STORAGE.favs, [...state.favorites]);
            renderAll();
            applyFilter();
            toast('info', state.favorites.has(id) ? 'Added to favorites' : 'Removed from favorites', TOOL_MAP[id].name);
            return;
        }
        const card = e.target.closest('.tool');
        if (card) {
            openTool(card.dataset.id);
        }
    });
    document.addEventListener('keydown', e => {
        const card = e.target.closest && e.target.closest('.tool');
        if (card && (e.key === 'Enter' || e.key === ' ')) {
            e.preventDefault(); openTool(card.dataset.id);
        }
    });

    // Modal events
    modal.addEventListener('click', e => {
        if (e.target.dataset.close !== undefined) closeModal();
    });
    document.querySelectorAll('.mode-btn').forEach(b => b.addEventListener('click', () => {
        document.querySelectorAll('.mode-btn').forEach(x => x.classList.remove('is-active'));
        b.classList.add('is-active');
        const fileMode = document.getElementById('fileMode');
        const textMode = document.getElementById('textMode');
        if (b.dataset.mode === 'text') { textMode.classList.add('is-active'); fileMode.style.display = 'none'; }
        else { textMode.classList.remove('is-active'); fileMode.style.display = ''; }
    }));

    // Upload area
    const uploadArea = document.getElementById('uploadArea');
    const fileInput = document.getElementById('fileInput');
    uploadArea.addEventListener('click', () => fileInput.click());
    uploadArea.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); } });
    uploadArea.addEventListener('dragover', e => { e.preventDefault(); uploadArea.classList.add('is-drag'); });
    uploadArea.addEventListener('dragleave', () => uploadArea.classList.remove('is-drag'));
    uploadArea.addEventListener('drop', e => { e.preventDefault(); uploadArea.classList.remove('is-drag'); handleFiles(e.dataTransfer.files); });
    fileInput.addEventListener('change', e => handleFiles(e.target.files));
    document.getElementById('fileList').addEventListener('click', e => {
        const rm = e.target.closest('[data-remove]');
        if (rm) {
            const i = +rm.dataset.remove;
            state.files.splice(i,1);
            drawFileList();
        }
    });

    // Process / reset
    document.getElementById('processBtn').addEventListener('click', runCurrent);
    document.getElementById('resetBtn').addEventListener('click', () => {
        if (state.confirm && (state.files.length || $text())) {
            if (!confirm('Clear current input?')) return;
        }
        resetToolUI();
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', e => {
        // ignore if typing
        const inField = /input|textarea|select/i.test(document.activeElement?.tagName || '');
        if (e.key === 'Escape') {
            if (modal.classList.contains('is-open')) closeModal();
            if (settingsModal.classList.contains('is-open')) closeSettings();
        }
        if (e.key === '/' && !inField) {
            e.preventDefault();
            document.getElementById('searchInput').focus();
        }
        if (e.key === '?' && !inField) {
            e.preventDefault(); openShortcutsHelp();
        }
        if (e.shiftKey && (e.key === 'T' || e.key === 't')) {
            const cur = document.documentElement.dataset.theme;
            setTheme(cur === 'dark' ? 'light' : 'dark');
        }
        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey) && modal.classList.contains('is-open')) {
            runCurrent();
        }
    });

    // Nav active state on scroll
    const sections = ['favorites','pdf','image','doc','convert','util'].map(id => document.getElementById(id+'-section')).filter(Boolean);
    const navLinks = [...document.querySelectorAll('[data-nav]')];
    const io = new IntersectionObserver(entries => {
        entries.forEach(en => {
            if (en.isIntersecting) {
                const id = en.target.id.replace('-section','');
                navLinks.forEach(a => a.classList.toggle('is-active', a.getAttribute('href') === '#' + id));
            }
        });
    }, { rootMargin: '-40% 0px -55% 0px' });
    sections.forEach(s => io.observe(s));

    // Update usage badge
    if (state.usage.date !== today()) state.usage = { date: today(), count: 0 };
    document.getElementById('statUsed').textContent = state.usage.count;
}

function bindSwitch(id, initial, onChange) {
    const el = document.getElementById(id);
    if (initial) el.classList.add('on');
    el.addEventListener('click', () => {
        el.classList.toggle('on');
        el.setAttribute('aria-checked', el.classList.contains('on') ? 'true' : 'false');
        onChange(el.classList.contains('on'));
    });
    el.addEventListener('keydown', e => { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); el.click(); } });
}

function openSettings() {
    settingsModal.classList.add('is-open');
    document.getElementById('settingsDrawer').classList.add('is-open');
    document.body.style.overflow = 'hidden';
}
function closeSettings() {
    settingsModal.classList.remove('is-open');
    document.getElementById('settingsDrawer').classList.remove('is-open');
    document.body.style.overflow = '';
}

window.openSettings = openSettings;
window.openShortcutsHelp = function() {
    closeSettings();
    state.currentTool = { id:'__help', name:'Shortcuts & Help', desc:'Keyboard shortcuts and tips', icon:'fa-keyboard', modes:['text'] };
    document.getElementById('modalTitle').textContent = state.currentTool.name;
    document.getElementById('modalDescription').textContent = state.currentTool.desc;
    document.getElementById('modalIcon').innerHTML = `<i class="fas fa-keyboard"></i>`;
    document.getElementById('modeToggle').classList.remove('is-visible');
    document.getElementById('fileMode').style.display = 'none';
    document.getElementById('textMode').classList.remove('is-active');
    document.getElementById('optionsPanel').classList.remove('is-visible');
    resetToolUI();
    const help =
`KEYBOARD SHORTCUTS
  /              Focus search
  Esc            Close modal / drawer
  Shift + T      Toggle dark mode
  ?              Show this help
  Ctrl/Cmd+Enter Run current tool

TIPS
  • Star a tool to pin it to your Favorites.
  • Recently used tools appear under Recent.
  • Files never leave your browser.
  • Switch text/file mode where supported.`;
    document.getElementById('outputContent').innerHTML = `<pre>${help}</pre>`;
    document.getElementById('outputEl').classList.add('is-visible');
    document.getElementById('modalActions').style.display = 'none';
    modal.classList.add('is-open');
    document.body.style.overflow = 'hidden';
    document.getElementById('copyOutBtn').onclick = () => navigator.clipboard.writeText(help).then(() => toast('success','Copied','Shortcuts copied'));
    document.getElementById('downloadTextBtn').onclick = () => downloadBlob(new Blob([help],{type:'text/plain'}), 'fimro-shortcuts.txt');
};
window.openAbout = function() {
    closeSettings();
    state.currentTool = { name:'About Fimro Flow', desc:'Local-first file toolkit', icon:'fa-bolt', modes:['text'] };
    document.getElementById('modalTitle').textContent = 'About Fimro Flow';
    document.getElementById('modalDescription').textContent = 'A delightful, private, in-browser toolkit';
    document.getElementById('modalIcon').innerHTML = `<i class="fas fa-bolt"></i>`;
    document.getElementById('modeToggle').classList.remove('is-visible');
    document.getElementById('fileMode').style.display = 'none';
    document.getElementById('textMode').classList.remove('is-active');
    document.getElementById('optionsPanel').classList.remove('is-visible');
    resetToolUI();
    document.getElementById('outputContent').innerHTML = `
        <div style="text-align:center; padding: .5rem 0 1rem;">
            <div style="width:80px;height:80px;border-radius:20px;background:var(--grad-brand);display:grid;place-items:center;margin:0 auto 1rem;color:white;font-size:1.8rem;box-shadow:var(--shadow-md);">
                <i class="fas fa-bolt"></i>
            </div>
            <h2 style="font-size:1.5rem; font-weight:800; margin-bottom:.5rem;">Fimro Flow <span style="background:var(--grad-brand);-webkit-background-clip:text;background-clip:text;color:transparent;">v2.0</span></h2>
            <p style="color:var(--text-soft); max-width:480px; margin: 0 auto 1.5rem;">A modern, privacy-first toolkit with ${TOOLS.length} tools for files, code, and everyday tasks — all running locally in your browser.</p>
            <div style="display:flex; gap:1rem; justify-content:center; flex-wrap:wrap;">
                <span class="tool-tag"><i class="fas fa-shield-halved"></i> 100% local</span>
                <span class="tool-tag"><i class="fas fa-bolt"></i> Lightning-fast</span>
                <span class="tool-tag"><i class="fas fa-heart"></i> Free forever</span>
            </div>
        </div>`;
    document.getElementById('outputEl').classList.add('is-visible');
    document.getElementById('modalActions').style.display = 'none';
    modal.classList.add('is-open');
    document.body.style.overflow = 'hidden';
};

/* When closing modal, restore action buttons visibility */
const observer = new MutationObserver(() => {
    if (!modal.classList.contains('is-open')) {
        document.getElementById('modalActions').style.display = '';
    }
});
observer.observe(modal, { attributes:true, attributeFilter:['class'] });

/* ---------------- Boot ---------------- */
function boot() {
    applyTheme();
    renderAll();
    applyFilter();
    initEvents();
    document.getElementById('statUsed').textContent = state.usage.count || 0;
    setTimeout(() => document.getElementById('appLoader').classList.add('is-gone'), 200);
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();

})();
